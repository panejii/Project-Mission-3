
<?= $this->extend('/dashboard_template'); ?>

<?= $this->section('content') ?>
<h3>Manage Students</h3>
<a href="/admin/students/add" class="btn btn-primary mb-3">Tambah Student</a>
<table class="table table-bordered">
    <thead>
        <tr>
            <th>Username</th>
            <th>Nama Lengkap</th>
            <th>Tahun Masuk</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($students as $student): ?>
        <tr>
            <td><?= esc($student['username']) ?></td>
            <td><?= esc($student['full_name'] ?? '-') ?></td>
            <td><?= esc($student['entry_year'] ?? '-') ?></td>
            <td>
                <a href="/admin/students/edit/<?= $student['student_id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                <a href="/admin/students/delete/<?= $student['student_id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus?')">Delete</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>
<?= $this->endSection() ?>