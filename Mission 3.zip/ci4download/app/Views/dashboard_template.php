<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container-fluid">
        <a class="navbar-brand" href="/dashboard">Proyek Kimak</a>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <!-- Menu untuk Admin -->
                <?php if (session()->get('role') === 'admin'): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="/admin/students">Manage Students</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/admin/courses">Manage Courses</a>
                    </li>
                <?php endif; ?>
                <!-- Menu untuk Student -->
                <?php if (session()->get('role') === 'student'): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="/student/courses">All Courses</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/student/enrolled">My Courses</a>
                    </li>
                <?php endif; ?>
            </ul>
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="btn btn-outline-danger" href="/login/logout">Logout</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<div class="container mt-4">
    <!-- Content akan diisi oleh masing-masing dashboard -->
    <?= $this->renderSection('content') ?>
</div>
</body>
</html>