<?= $this->extend('/dashboard_template') ?>
<?= $this->section('content') ?>

<h3>My Courses</h3>
<table class="table table-bordered">
    <thead>
        <tr>
            <th>Nama Course</th>
            <th>Credits</th>
            <th>Tanggal Enroll</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($mycourses as $course): ?>
        <tr>
            <td><?= esc($course['course_name']) ?></td>
            <td><?= esc($course['credits']) ?></td>
            <td><?= esc($course['enroll_date']) ?></td>
            <td>
                <a href="<?= base_url('/student/courses/unenroll/' . $course['course_id']) ?>"
                   class="btn btn-danger btn-sm"
                   onclick="return confirm('Yakin ingin membatalkan enroll?');">
                   Batalkan
                </a>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?= $this->endSection() ?>