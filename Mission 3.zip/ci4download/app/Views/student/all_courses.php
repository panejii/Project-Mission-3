
<?= $this->extend('/dashboard_template') ?>
<?= $this->section('content') ?>

<h3>All Courses</h3>
<table class="table table-bordered">
    <thead>
        <tr>
            <th>Nama Course</th>
            <th>Credits</th>
            <th>Enroll Course</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($courses as $course): ?>
        <tr>
            <td><?= esc($course['course_name']) ?></td>
            <td><?= esc($course['credits']) ?></td>
            <td>
                <?php
                $enrolled = false;
                foreach ($enrollments as $enroll) {
                    if ($enroll['course_id'] == $course['course_id']) {
                        $enrolled = true;
                        break;
                    }
                }
                ?>
                <?php if ($enrolled): ?>
                    <button class="btn btn-secondary btn-sm" disabled>Enrolled</button>
                <?php else: ?>
                    <form method="post" action="/student/courses/enroll/<?= $course['course_id'] ?>">
                        <button type="submit" class="btn btn-success btn-sm">Enroll</button>
                    </form>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?= $this->endSection() ?>