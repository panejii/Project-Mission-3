<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Login::index');             // default halaman awal langsung ke login
$routes->get('/login', 'Login::index');        // form login
$routes->post('/login/auth', 'Login::auth');   // proses login
$routes->get('/login/logout', 'Login::logout');      // logout
$routes->get('/register', 'RegisterController::index');
$routes->post('/register/save', 'RegisterController::save');

$routes->get('/dashboard', 'Dashboard::index'); // dashboard


// ...existing code...
$routes->group('admin', function($routes) {
    $routes->get('students', 'Admin\Students::index');
    $routes->get('students/add', 'Admin\Students::add');
    $routes->post('students/save', 'Admin\Students::save');
    $routes->get('students/edit/(:num)', 'Admin\Students::edit/$1');
    $routes->get('students/edit/(:num)', 'Admin\Students::edit/$1');
    $routes->post('students/update/(:num)', 'Admin\Students::update/$1');
    $routes->get('students/delete/(:num)', 'Admin\Students::delete/$1');
    $routes->get('courses', 'Admin\Courses::index');
    $routes->get('courses/add', 'Admin\Courses::add');
    $routes->post('courses/save', 'Admin\Courses::save');
    $routes->get('courses/edit/(:num)', 'Admin\Courses::edit/$1');
    $routes->post('courses/update/(:num)', 'Admin\Courses::update/$1');
    $routes->get('courses/delete/(:num)', 'Admin\Courses::delete/$1'); 
});


$routes->get('student/courses', 'Student\Courses::index');
$routes->post('student/courses/enroll/(:num)', 'Student\Courses::enroll/$1');
$routes->get('/student/enrolled', 'Student\Courses::enrolled');
$routes->get('student/courses/unenroll/(:num)', 'Student\Courses::unenroll/$1');

// ...existing code...

