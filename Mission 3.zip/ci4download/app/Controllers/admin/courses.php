<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\CourseModel;

class Courses extends BaseController
{
    public function index()
    {
        if (!session()->get('logged_in')) {
            return redirect()->to('/login');
            }
        $courseModel = new \App\Models\CourseModel();
        $courses = $courseModel->findAll();
        return view('admin/manage_courses', ['courses' => $courses]);
    }

    public function add()
    {
        return view('admin/add_course');
    }

    public function save()
    {
        $courseModel = new CourseModel();
        $courseModel->insert([
            'course_name' => $this->request->getPost('course_name'),
            'credits'     => $this->request->getPost('credits')
        ]);
        return redirect()->to('/admin/courses');
    }

   public function edit($course_id)
    {
        $courseModel = new CourseModel();
        $course = $courseModel->find($course_id);
        return view('admin/edit_course', ['course' => $course]);
    }

    public function update($course_id)
    {
        $courseModel = new CourseModel();
        $courseModel->update($course_id, [
            'course_name' => $this->request->getPost('course_name'),
            'credits'     => $this->request->getPost('credits')
        ]);
        return redirect()->to('/admin/courses');
    }

    public function delete($course_id)
    {
        $courseModel = new CourseModel();
        $courseModel->delete($course_id);
        return redirect()->to('/admin/courses');
    }

}