<?php


namespace App\Controllers\Student;

use App\Controllers\BaseController;
use App\Models\CourseModel;

class Courses extends BaseController
{
    public function index()
    {
        if (!session()->get('logged_in')) {
            return redirect()->to('/login');
        }

        $courseModel = new CourseModel();
        $courses = $courseModel->findAll(); 

        $student_id = session()->get('student_id');
        $db = \Config\Database::connect();
        $enrollments = $db->table('takes')->where('student_id', $student_id)->get()->getResultArray();

        return view('student/all_courses', [
            'courses' => $courses,
            'enrollments' => $enrollments
        ]);
    }

    public function enroll($course_id)
    {
        if (!session()->get('logged_in')) {
            return redirect()->to('/login');
        }

        $student_id = session()->get('student_id');
        if (!$student_id) {
            // Jika belum ada di session, ambil dari tabel students
            $user_id = session()->get('user_id');
            $studentModel = new \App\Models\StudentModel();
            $student = $studentModel->where('user_id', $user_id)->first();
            $student_id = $student['student_id'];
            session()->set('student_id', $student_id);
        }

        $db = \Config\Database::connect();
        $db->table('takes')->insert([
            'student_id'  => $student_id,
            'course_id'   => $course_id,
            'enroll_date' => date('Y-m-d')
        ]);

        return redirect()->to('/student/courses')->with('success', 'Berhasil enroll course!');
    }

    public function enrolled()
    {
        if (!session()->get('logged_in')) {
            return redirect()->to('/login');
        }

        $student_id = session()->get('student_id');
        $db = \Config\Database::connect();

        // Ambil course yang sudah di-enroll student ini
        $builder = $db->table('takes');
        $builder->select('courses.course_id, courses.course_name, courses.credits, takes.enroll_date');
        $builder->join('courses', 'courses.course_id = takes.course_id');
        $builder->where('takes.student_id', $student_id);
        $mycourses = $builder->get()->getResultArray();

        return view('student/my_courses', [
            'mycourses' => $mycourses
        ]);
    }

   public function unenroll($course_id)
{
    // Cek apakah user sudah login
    if (!session()->get('logged_in')) {
        return redirect()->to('/login');
    }

    // Ambil student_id dari session
    $student_id = session()->get('student_id');

    // Koneksi ke database
    $db = \Config\Database::connect();

    // Hapus data dari tabel takes
    $db->table('takes')
        ->where('student_id', $student_id)
        ->where('course_id', $course_id)
        ->delete();

    // Redirect kembali ke halaman daftar kursus yang diambil
    return redirect()->to('/student/enrolled')->with('success', 'Berhasil membatalkan enroll!');
}
   

}